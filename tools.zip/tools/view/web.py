import os
import sys
import time
from rich import print as printf
from rich.panel import Panel

class DIPERLUKAN:

    def __init__(self) -> None:
        pass

    # Menampilkan UI dan mengarahkan ke URL
    def run(self):
        printf(Panel("[bold white]Membuka Zefoy...", width=40, style="bold bright_white"))
        time.sleep(2)  # Delay sebelum membuka URL
        os.system("termux-open https://zefoy.com")  # Membuka URL dengan termux
        sys.exit()

if __name__ == "__main__":
    app = DIPERLUKAN()
    app.run()
