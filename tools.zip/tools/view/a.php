<?php
// fungsi untuk mencetak teks berwarna
function warna($kode, $teks) {
    return "\033[" . $kode . "m" . $teks . "\033[0m";
}

// header dengan dekorasi
echo "╭" . str_repeat('─', 54) . "╮\n";
echo "│ " . str_repeat('● ', 3) . str_repeat(' ', 44) . "│\n";

// teks `zefoy` dengan setengah atas merah dan setengah bawah putih
echo "│ " . warna('41;97', " ______     ______     ______   ______     __  __   ") . " │\n";
echo "│ " . warna('41;97', "/\\___  \\   /\\  ___\\   /\\  ___\\ /\\  __ \\   /\\ \\_\\ \\  ") . " │\n";
echo "│ " . warna('47;30', "\\/_/  /__  \\ \\  __\\   \\ \\  __\\ \\ \\ \\/\\ \\  \\ \\____ \\ ") . " │\n";
echo "│ " . warna('47;30', "   /\\_____\\  \\ \\_____\\  \\ \\_\\    \\ \\_____\\  \\/_____/ ") . " │\n";
echo "│ " . warna('47;30', "   \\/_____/   \\/_____/   \\/_/     \\/_____/   \\/_____/ ") . " │\n";

// footer teks tambahan
echo "│         Free Tiktok Views - Coded by Rozhak         │\n";
echo "╰" . str_repeat('─', 54) . "╯\n";

// petunjuk tambahan
echo "╭" . str_repeat('─', 19) . " [ Link Video ] " . str_repeat('─', 20) . "╮\n";
echo "│ Please fill in your tiktok video link, make sure the │\n";
echo "│ account is not private and the                       │\n";
echo "│ link is correct. Take the video link via browser!    │\n";
echo "╰─ ╭───── " . str_repeat('─', 42) . "╯\n";
echo "   ╰─> u\n";
?>
