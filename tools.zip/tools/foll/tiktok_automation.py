import subprocess
import time
import os
import sys
from rich.console import Console
from rich.panel import Panel
from rich import print as printf

console = Console()

def clear_screen():
    os.system('clear' if os.name == 'posix' else 'cls')

def display_banner():
    clear_screen()
    printf(Panel(
        "[bold red]● [bold yellow]● [bold green]●[bold white]\n"
        "[bold cyan]TikTok Automation Tool[/bold cyan]\n"
        "[bold white]Auto Link Submission[/bold white]",
        width=60
    ))

def validate_link(link):
    return "tiktok.com" in link.lower()

def main():
    try:
        display_banner()
        
        # Get TikTok link
        printf(Panel("[bold white]Enter your TikTok link (must contain 'tiktok.com'):", width=60))
        link = console.input("[bold cyan]>>> ")
        
        if not validate_link(link):
            printf(Panel("[bold red]Invalid TikTok link! Please include 'tiktok.com' in the link.", width=60))
            return
        
        # Get number of iterations
        printf(Panel("[bold white]Enter number of times to run:", width=60))
        try:
            iterations = int(console.input("[bold cyan]>>> "))
            if iterations < 1:
                raise ValueError
        except ValueError:
            printf(Panel("[bold red]Please enter a valid positive number!", width=60))
            return
        
        # Main automation loop
        for i in range(iterations):
            clear_screen()
            printf(Panel(f"""[bold white]Status: Running iteration {i+1}/{iterations}
Link: {link}""", width=60))
            
            try:
                # Run the Zefoy script
                process = subprocess.Popen(['python', 'zefoy_script.py'],
                                        stdin=subprocess.PIPE,
                                        text=True)
                
                # Send the link
                process.communicate(input=f"{link}\n")
                
                # First wait period
                for remaining in range(30, 0, -1):
                    printf(f"[bold cyan]Waiting: [bold white]{remaining}[bold cyan] seconds remaining...          ", end='\r')
                    time.sleep(1)
                
                # Second wait period (1.3 minutes = 78 seconds)
                for remaining in range(78, 0, -1):
                    printf(f"[bold yellow]Cooldown: [bold white]{remaining}[bold yellow] seconds remaining...          ", end='\r')
                    time.sleep(1)
                
            except Exception as e:
                printf(Panel(f"[bold red]Error occurred: {str(e)}", width=60))
                return
            
            if i < iterations - 1:  # Don't show "Starting next iteration" on the last run
                printf("\n[bold green]Starting next iteration...          ")
                time.sleep(2)
        
        # Completion message
        printf(Panel("[bold green]Automation completed successfully!", width=60))
        time.sleep(3)
        
    except KeyboardInterrupt:
        printf(Panel("[bold yellow]Program stopped by user.", width=60))
    except Exception as e:
        printf(Panel(f"[bold red]An error occurred: {str(e)}", width=60))
    finally:
        sys.exit()

if __name__ == "__main__":
    main()
