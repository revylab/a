#!/usr/bin/env php
<?php

function clearScreen() {
    system('clear');
}

function printTitle() {
    echo "\033[1;36m";
    echo "
██████╗ ███████╗██╗   ██╗██╗   ██╗██╗      █████╗ ██████╗ 
██╔══██╗██╔════╝██║   ██║╚██╗ ██╔╝██║     ██╔══██╗██╔══██╗
██████╔╝█████╗  ██║   ██║ ╚████╔╝ ██║     ███████║██████╔╝
██╔══██╗██╔══╝  ╚██╗ ██╔╝  ╚██╔╝  ██║     ██╔══██║██╔══██╗
██║  ██║███████╗ ╚████╔╝    ██║   ███████╗██║  ██║██████╔╝
╚═╝  ╚═╝╚══════╝  ╚═══╝     ╚═╝   ╚══════╝╚═╝  ╚═╝╚═════╝ 
    \n";
    echo "\033[0m";
}

function printLine() {
    echo "\033[1;33m";
    echo "================================================\n";
    echo "\033[0m";
}

function getUserInput() {
    echo "\033[1;32m[?]\033[0m Masukkan username TikTok: ";
    $username = trim(fgets(STDIN));
    
    echo "\033[1;32m[?]\033[0m Berapa kali program akan dijalankan: ";
    $iterations = (int)trim(fgets(STDIN));
    
    echo "\033[1;32m[?]\033[0m Masukkan cooldown dalam menit: ";
    $cooldown = (int)trim(fgets(STDIN));
    
    return [$username, $iterations, $cooldown];
}

function runBot($username, $iterations, $cooldown) {
    $descriptorspec = array(
        0 => array("pipe", "r"),  // stdin
        1 => array("pipe", "w"),  // stdout
        2 => array("pipe", "w")   // stderr
    );

    $totalIterations = 0;

    for ($i = 1; $i <= $iterations; $i++) {
        clearScreen();
        printTitle();
        printLine();
        
        echo "\033[1;34m[INFO]\033[0m Menjalankan bot untuk username: \033[1;33m$username\033[0m\n";
        echo "\033[1;34m[INFO]\033[0m Iterasi ke: \033[1;33m$i\033[0m dari \033[1;33m$iterations\033[0m\n";
        echo "\033[1;34m[INFO]\033[0m Total iterasi: \033[1;33m$totalIterations\033[0m\n";
        printLine();
        
        // Jalankan bot.php
        $process = proc_open('php bot.php', $descriptorspec, $pipes);

        if (is_resource($process)) {
            // Kirim username dan enter
            fwrite($pipes[0], $username . "\n");
            
            // Tampilkan output dari bot.php
            while (!feof($pipes[1])) {
                echo fgets($pipes[1]);
            }

            // Tutup pipes
            fclose($pipes[0]);
            fclose($pipes[1]);
            fclose($pipes[2]);

            // Tunggu proses selesai
            proc_close($process);
            $totalIterations++;
        }
        
        if ($i < $iterations) {
            echo "\n\033[1;35m[WAIT]\033[0m Total iterasi: \033[1;33m$totalIterations\033[0m\n";
            echo "\033[1;35m[WAIT]\033[0m Cooldown selama \033[1;33m$cooldown\033[0m menit...\n";
            
            // Hitung mundur
            for ($j = $cooldown * 60; $j > 0; $j--) {
                echo "\r\033[1;35m[TIMER]\033[0m Sisa waktu: \033[1;33m" . gmdate("i:s", $j) . "\033[0m ";
                sleep(1);
            }
            echo "\n";
        }
    }
    
    echo "\n\033[1;32m[SUCCESS]\033[0m Program selesai dijalankan!\n";
    echo "\033[1;34m[INFO]\033[0m Total iterasi: \033[1;33m$totalIterations\033[0m\n";
    printLine();
}

// Main Program
clearScreen();
printTitle();
printLine();

echo "\033[1;34m[INFO]\033[0m TikTok Bot Runner v1.0\n";
printLine();

list($username, $iterations, $cooldown) = getUserInput();
runBot($username, $iterations, $cooldown);

?>
